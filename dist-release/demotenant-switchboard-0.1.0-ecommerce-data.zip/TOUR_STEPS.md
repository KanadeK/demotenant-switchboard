# Northstar Shop Tour

Dataset checksum: `96d7f7983ff06a50aeac8b13461614714427b16a7e7c179ec71a935b39717f05`


1. **Open the tenant overview**  
   Actor: `alex-admin`  
   Route: `/`  
   Assertion: `100 records`

2. **Review the persona roster**  
   Actor: `alex-admin`  
   Route: `/personas`  
   Assertion: `Personas`

3. **Switch to operations context**  
   Actor: `mina-ops`  
   Route: `/personas`  
   Assertion: `Operations Lead`

4. **Inspect order records**  
   Actor: `mina-ops`  
   Route: `/records`  
   Assertion: `Records`

5. **Verify timeline context**  
   Actor: `omar-finance`  
   Route: `/timeline`  
   Assertion: `Timeline`

6. **Confirm scenario type**  
   Actor: `luca-marketing`  
   Route: `/`  
   Assertion: `ecommerce`

7. **Read the scripted tour**  
   Actor: `priya-support`  
   Route: `/tour`  
   Assertion: `Tour`

8. **Return to checksum**  
   Actor: `alex-admin`  
   Route: `/`  
   Assertion: `Checksum`

