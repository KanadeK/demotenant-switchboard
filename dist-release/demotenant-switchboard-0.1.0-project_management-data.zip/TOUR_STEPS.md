# Atlas Projects Tour

Dataset checksum: `0408b4c55e7ad0855b922ae28c24160194a933db71d67db8f74b6c7ba97d17e1`


1. **Open the program overview**  
   Actor: `dana-admin`  
   Route: `/`  
   Assertion: `100 records`

2. **Review project personas**  
   Actor: `dana-admin`  
   Route: `/personas`  
   Assertion: `Personas`

3. **Switch to product management**  
   Actor: `keiko-pm`  
   Route: `/personas`  
   Assertion: `Product Manager`

4. **Inspect work records**  
   Actor: `sam-engineer`  
   Route: `/records`  
   Assertion: `Records`

5. **Explain delivery timeline**  
   Actor: `ines-design`  
   Route: `/timeline`  
   Assertion: `Timeline`

6. **Confirm project scenario**  
   Actor: `theo-exec`  
   Route: `/`  
   Assertion: `project_management`

7. **Run guided tour**  
   Actor: `dana-admin`  
   Route: `/tour`  
   Assertion: `Tour`

8. **Confirm deterministic checksum**  
   Actor: `theo-exec`  
   Route: `/`  
   Assertion: `Checksum`

