# Beacon Support Tour

Dataset checksum: `472ff664d5b71b30e46060fb1bc50735b57dcdbd33ae41a669cd3bc3df9ddbb3`


1. **Open the support overview**  
   Actor: `noah-admin`  
   Route: `/`  
   Assertion: `100 records`

2. **Review support personas**  
   Actor: `noah-admin`  
   Route: `/personas`  
   Assertion: `Personas`

3. **Switch to frontline agent**  
   Actor: `aria-agent`  
   Route: `/personas`  
   Assertion: `Tier One Agent`

4. **Inspect ticket records**  
   Actor: `ben-escalation`  
   Route: `/records`  
   Assertion: `Records`

5. **Explain SLA timeline**  
   Actor: `maya-success`  
   Route: `/timeline`  
   Assertion: `Timeline`

6. **Confirm support scenario**  
   Actor: `nina-qa`  
   Route: `/`  
   Assertion: `support_desk`

7. **Read guided tour**  
   Actor: `noah-admin`  
   Route: `/tour`  
   Assertion: `Tour`

8. **Confirm deterministic checksum**  
   Actor: `ben-escalation`  
   Route: `/`  
   Assertion: `Checksum`

