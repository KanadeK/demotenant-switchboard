from pathlib import Path

from playwright.sync_api import expect, sync_playwright


def run() -> None:
    html = Path(__file__).with_name("demo.html").resolve().as_uri()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": 1280, "height": 900})
        page.goto(html)

        page.locator("[data-route='/']").click()
        expect(page.locator("[data-testid='record-count']")).to_contain_text("100 records")

        page.locator("[data-route='/personas']").click()
        expect(page.locator("[data-testid='personas-title']")).to_contain_text("Personas")

        page.locator("[data-route='/personas']").click()
        expect(page.locator("[data-testid='persona-aria-agent']")).to_contain_text("Tier One Agent")

        page.locator("[data-route='/records']").click()
        expect(page.locator("[data-testid='records-title']")).to_contain_text("Records")

        page.locator("[data-route='/timeline']").click()
        expect(page.locator("[data-testid='timeline-title']")).to_contain_text("Timeline")

        page.locator("[data-route='/']").click()
        expect(page.locator("[data-testid='scenario-kind']")).to_contain_text("support_desk")

        page.locator("[data-route='/tour']").click()
        expect(page.locator("[data-testid='tour-title']")).to_contain_text("Tour")

        page.locator("[data-route='/']").click()
        expect(page.locator("[data-testid='checksum']")).to_contain_text("Checksum")

        browser.close()


if __name__ == "__main__":
    run()
